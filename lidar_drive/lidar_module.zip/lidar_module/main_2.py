'''
기존 코드(C:\Users\plane\Desktop\park_ws\lidar_test5.py)에서 문제점은 코드가 장황하여 가독성이 낮고 반복되는 문장이 많아 작동 시간이 다소 오래 걸리며
이는 곧 코드가 사용하는 메모리가 많아진다는 문제점이며 이는 라즈베리파이에서 가동할 때에는 상당히 치명적인 약점으로 부각될 것이다.

따라서 본 코드는 lidar_test5.py의 문제점에 대해 개선하여 작성하였다.

본 코드는 기본적으로 lidar_test5.py의 함수들을 모듈화하여 디버깅과 가독성을 높힌 코드이다.
따라서 기본적인 포멧과 로직은 lidar_test5.py와 유사하다.

하지만 기존에 배열을 초기화하기 위해 반복적인 문장을 썼던 것을 반복적인 문장 자체를 모듈화를 하여 해결했으며
실행 시간 단축을 위해 '기본 정면 각도 -> 단위 거리 -> 단위 거리별 각도' 순으로 실행되게 작성했다.
또한 변수 및 배열의 이름을 직관적으로 고쳤다.

아쉬운 점이 있다면...
    1. 거리별 개체의 크기를 파라미터값으로 넣을 수 없었다는 점
    2. 본 코드가 정면만을 측정하여 정면에 객체가 있을 시 그 다음으로 좌회전이나 우회전을 하기위해
       정면 뿐만 아닌 좌우로 더 넓은 시야각을 확보해야 한다는 점
       
개선 방안(다음 코드 작성시 참고할 것)
    1. math 함수를 통해 피타고라스 법칙 및 삼각함수(인버스 코사인 등)로 파라미터를 조절할 수 있게 할 것이다.
    2. 더 넓은 시야각을 가진 코드를 짜야한다고 생각한다 -> 이는 lidar_test5.py와는 다른 양상으로 진행해야 할 것이다.    
'''

#!/usr/bin/env python3

import rospy
from sensor_msgs.msg import LaserScan
import math

#lidar_module----------------------------------
import lidar_12m, lidar_10m, lidar_5m, lidar_1m
import dectet
#----------------------------------------------

def RAD2DEG(x):
    return x * 180.0 / math.pi

def scanCallback(scan):
    count = int(scan.scan_time / scan.time_increment)
    rospy.loginfo("I heard a laser scan %s[%d]:" % (scan.header.frame_id, count))
    for i in range(count):
        degree = RAD2DEG(scan.angle_min + scan.angle_increment * i)
        dist = scan.ranges[i]

        if (165.000000 < degree <= 180.000000) and (-180.000000 <= degree < -165.000000):
            if (0.500000 < dist <= 1.000000):
                len_1_1 = lidar_1m.detect(degree)
            elif (1.000000 < dist <= 5.000000):
                len_5_1 = lidar_5m.detect(degree)    
            elif (5.000000 < dist <= 10.000000):
                len_10_1 = lidar_10m.detect(degree)
            elif (10.000000 < dist <= 12.000000):
                len_12_1 = lidar_12m.detect(degree)
        
        len_12_2 = len(len_12_1)
        len_10_2 = len(len_10_1) 
        len_5_2 = len(len_5_1)
        len_1_2 = len(len_1_1)
        
        #객체의 크기는 10cm + α 로 설정.
        dist_1, dist_2 = dectet.judge(len_12_2, len_10_2, len_5_2, len_1_2)

        if 0.5 <= dist_1 and 1.0 <= dist_2 :
            print(f'Obstacle detected %.1f ~ %.1f meters ahead, directly in front. Prepare to decelerate.'%(dist_1, dist_2))
        else:
            print('no object on your front')

def main():
    rospy.init_node("rplidar_node_client")
    rospy.Subscriber("/scan", LaserScan, scanCallback)
    rospy.spin()

if __name__ == "__main__":
    main()