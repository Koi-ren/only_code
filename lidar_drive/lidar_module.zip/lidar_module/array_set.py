
array_mid = []

array_mid_1 = []
array_mid_2 = []
array_mid_3 = []

mid_len_1 = 0
mid_len_2 = 0